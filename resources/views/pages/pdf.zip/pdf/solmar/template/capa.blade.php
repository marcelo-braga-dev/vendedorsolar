<div>
    <div>
        <img src="storage/proposta-comercial/solmar/template/capa_1.jpg"/>
    </div>
    <div style="margin-top:-200px; text-align:right; padding-right:35px;color:rgb(68,90,99)">
        <span style="font-size:22px;">{{ getNomeCliente($orcamento->clientes_id) }}</span><br>
        #{{ $orcamento->id }}
    </div>
</div>
