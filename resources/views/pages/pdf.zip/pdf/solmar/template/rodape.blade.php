<div style="font-style: italic;">
    <div>
        <img src="storage/proposta-comercial/solmar/template/rodape.jpg"/>
    </div>
    <div style="margin-top:-30px; text-align:center;color:black">
        <span style="font-size:16px; color: white">www.solmarenergia.com.br</span>
    </div>
</div>
