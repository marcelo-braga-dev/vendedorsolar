<img src="storage/proposta-comercial/solmar/template/cabecalho.jpg"/>
